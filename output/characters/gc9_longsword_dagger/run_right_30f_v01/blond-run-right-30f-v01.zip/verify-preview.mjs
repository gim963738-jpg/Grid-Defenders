import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
const directory = path.dirname(fileURLToPath(import.meta.url));
const tempPrefix = path.join(os.tmpdir(), 'grid-defenders-run-review-');
const profile = fs.mkdtempSync(tempPrefix);
const edge = spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'], { windowsHide: true, stdio: 'ignore' });
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
let socket;
try {
  let port;
  for (let i=0; i<100; i++) {
    const filename = path.join(profile, 'DevToolsActivePort');
    if (fs.existsSync(filename)) { port = fs.readFileSync(filename,'utf8').split('\n')[0]; break; }
    await pause(100);
  }
  if (!port) throw Error('Edge debugging endpoint did not start');
  const tabs = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  socket = new WebSocket(tabs.find(tab => tab.type==='page').webSocketDebuggerUrl);
  await new Promise((resolve,reject) => { socket.onopen=resolve; socket.onerror=reject; });
  let serial=0;
  const pending = new Map();
  socket.onmessage = event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) {
      const {resolve,reject} = pending.get(message.id); pending.delete(message.id);
      if (message.error) reject(Error(JSON.stringify(message.error))); else resolve(message.result);
    }
  };
  function call(method,params={}) {
    const id=++serial;
    return new Promise((resolve,reject) => { pending.set(id,{resolve,reject}); socket.send(JSON.stringify({id,method,params})); });
  }
  async function evaluate(expression) {
    const result = await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});
    if (result.exceptionDetails) throw Error(JSON.stringify(result.exceptionDetails));
    return result.result.value;
  }
  await call('Page.enable');
  await call('Emulation.setDeviceMetricsOverride',{width:1100,height:900,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:pathToFileURL(path.join(directory,'preview.html')).href});
  let ready=false;
  for (let i=0;i<100;i++) { ready=await evaluate('document.documentElement.dataset.ready === "true"'); if(ready)break; await pause(100); }
  if(!ready) throw Error('Preview failed to load atlas');
  const report = await evaluate(`(() => {
    const p=window.spritePreview, result={imageReady:true, defaultInfinite:p.looping};
    p.selectFrame(0); document.getElementById('previous').click(); result.previousWraps=p.current===29;
    document.getElementById('next').click(); result.nextWraps=p.current===0;
    result.everyFrameSelectable=true;
    for(let i=0;i<30;i++){ const s=document.getElementById('frame'); s.value=String(i); s.dispatchEvent(new Event('input')); result.everyFrameSelectable &&= p.current===i && !p.playing && document.getElementById('counter').value.startsWith(String(i+1).padStart(2,'0')); }
    p.selectFrame(29); p.setPlaying(true); p.tick(10000); p.tick(10000+1000/30); result.loopWraps=p.current===0 && p.playing;
    p.tick(10000+61000/30); result.multipleLoops=p.current===0 && p.playing;
    document.getElementById('play').click(); result.pauseWorks=!p.playing;
    document.getElementById('play').click(); result.resumeWorks=p.playing;
    document.getElementById('loop').click(); p.selectFrame(0); p.setPlaying(true); p.tick(20000); p.tick(21000);
    result.loopOffStops=!p.looping && !p.playing && p.current===29 && document.getElementById('loop').getAttribute('aria-pressed')==='false';
    document.getElementById('loop').click(); result.loopOnRestarts=p.looping && p.playing;
    document.getElementById('seam').click(); result.seamStarts=p.current===26 && p.looping && p.playing;
    p.tick(30000); p.tick(30000+4000/30); result.seamReachesFirst=p.current===0 && p.playing;
    const speed=document.getElementById('fps'); speed.value='15'; speed.dispatchEvent(new Event('change')); p.selectFrame(0); p.setPlaying(true); p.tick(40000); p.tick(41000); result.speedWorks=p.current===15;
    speed.value='30'; speed.dispatchEvent(new Event('change')); p.setPlaying(false);
    document.querySelector('[data-background=light]').click(); result.lightWorks=document.getElementById('stage').classList.contains('light');
    document.querySelector('[data-background=dark]').click(); result.darkWorks=document.getElementById('stage').classList.contains('dark');
    result.numberedCells=document.querySelectorAll('.order-number').length;
    return result;
  })()`);
  const checks = ['imageReady','defaultInfinite','previousWraps','nextWraps','everyFrameSelectable','loopWraps','multipleLoops','pauseWorks','resumeWorks','loopOffStops','loopOnRestarts','seamStarts','seamReachesFirst','speedWorks','lightWorks','darkWorks'];
  if(checks.some(key=>!report[key]) || report.numberedCells!==30) throw Error(JSON.stringify(report));
  const atlasData = 'data:image/png;base64,'+fs.readFileSync(path.join(directory,'run-right-30f.png')).toString('base64');
  const webp=await evaluate(`(async()=>{ const im=new Image(); im.src=${JSON.stringify(atlasData)}; await im.decode(); const c=document.createElement('canvas'); c.width=768;c.height=640;const ctx=c.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.drawImage(im,0,0,768,640);return c.toDataURL('image/webp',0.88); })()`);
  fs.writeFileSync(path.join(directory,'preview-atlas.webp'),Buffer.from(webp.split(',')[1],'base64'));
  for(const [background,frame] of [['light',0],['dark',18]]) {
    await evaluate(`document.querySelector('[data-background=${background}]').click();window.spritePreview.selectFrame(${frame});`);
    const shot=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
    fs.writeFileSync(path.join(directory,`preview-browser-${background}.png`),Buffer.from(shot.data,'base64'));
  }
  await call('Emulation.setDeviceMetricsOverride',{width:390,height:900,deviceScaleFactor:1,mobile:true});
  report.mobile390=await evaluate(`({noHorizontalOverflow:document.documentElement.scrollWidth<=innerWidth,controlMinHeight:Math.min(...Array.from(document.querySelectorAll('button,select,input')).map(e=>e.getBoundingClientRect().height))})`);
  const animated=fs.readFileSync(path.join(directory,'run-right-animated.png')).toString('base64');
  report.apng=await evaluate(`(async()=>{
    const bytes=Uint8Array.from(atob(${JSON.stringify(animated)}),c=>c.charCodeAt(0));const decoder=new ImageDecoder({data:bytes,type:'image/png',preferAnimation:true});await decoder.tracks.ready;await decoder.completed;
    const t=decoder.tracks.selectedTrack,r={frameCount:t.frameCount,animated:t.animated,repetitionCount:String(t.repetitionCount),decodedFrames:0,durationMs:0,allFrames256:true};
    for(let i=0;i<t.frameCount;i++){const f=(await decoder.decode({frameIndex:i,completeFramesOnly:true})).image;r.decodedFrames++;r.durationMs+=f.duration/1000;r.allFrames256 &&= f.displayWidth===256 && f.displayHeight===256;f.close();}decoder.close();return r;
  })()`);
  if(!report.mobile390.noHorizontalOverflow || report.mobile390.controlMinHeight<48 || report.apng.decodedFrames!==30 || !report.apng.allFrames256 || report.apng.durationMs!==1000 || report.apng.repetitionCount!=='Infinity') throw Error(JSON.stringify(report));
  const scratch=process.env.ORCA_CHAT_SCRATCH_DIR;
  if(scratch){
    let inline=fs.readFileSync(path.join(directory,'preview.html'),'utf8');
    inline=inline.replaceAll('run-right-30f.png',webp).replace('const CELL = 256,','const CELL = 128,').replace(/      <div class="buttons downloads">.*?<\/div>\r?\n/,'').replace('width: min(100%, 512px)','width: min(100%, 320px)');
    inline=inline.replace(/(<img class="atlas" src=")[^"]+(" alt=)/,'$1$2').replace('image.onload = () => { ready = true;','image.onload = () => { document.querySelector(\'.atlas\').src = image.src; ready = true;');
    report.inline={file:'blond-run-right-30f-v01.html',bytes:Buffer.byteLength(inline)};
    if(report.inline.bytes>=512*1024) throw Error('Inline preview exceeds size limit');
    fs.writeFileSync(path.join(scratch,report.inline.file),inline);
    await call('Page.navigate',{url:pathToFileURL(path.join(scratch,report.inline.file)).href});
    let inlineReady=false;
    for(let i=0;i<100;i++){inlineReady=await evaluate('document.documentElement.dataset.ready === "true"');if(inlineReady)break;await pause(50);}
    report.inline.ready=inlineReady;
    if(!inlineReady)throw Error('Inline atlas failed to load');
  }
  await call('Emulation.setDeviceMetricsOverride',{width:1536,height:1344,deviceScaleFactor:1,mobile:false});
  await call('Page.navigate',{url:pathToFileURL(path.join(directory,'order.html')).href});
  let orderReady=false;
  for(let i=0;i<100;i++){orderReady=await evaluate('document.querySelector("img")?.complete && document.querySelector("img")?.naturalWidth===1536 && document.querySelectorAll(".number").length===30');if(orderReady)break;await pause(50);}
  if(!orderReady)throw Error('Numbered sheet failed to load');
  await evaluate('document.fonts.ready');
  const numbered=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});
  fs.writeFileSync(path.join(directory,'run-right-30f-numbered.png'),Buffer.from(numbered.data,'base64'));
  fs.writeFileSync(path.join(directory,'browser-verification.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report));
  await call('Browser.close');
} finally {
  socket?.close();if(edge.exitCode===null)edge.kill();await pause(600);
  if(path.resolve(profile).startsWith(path.resolve(tempPrefix)) && path.dirname(profile)===path.dirname(tempPrefix)){
    try{fs.rmSync(profile,{recursive:true,force:true,maxRetries:3,retryDelay:200});}catch{}
  }
}
